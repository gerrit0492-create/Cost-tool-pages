# Cost-tool-pages — Auto Clean Package

Upload deze ZIP naar de repo-root. Door de workflow **Auto Unpack & Clean (no-click after ZIP upload)** 
die automatisch triggert op `push` van `*.zip`, wordt alles uitgepakt, opgeschoond en gecommit naar `main`.
Bij 'race conditions' valt de workflow terug op een branch en geeft een klikbare merge-link.
