# Cost-tool-pages (Clean)

Deze snapshot bevat een opgeschoonde mappenstructuur:
- `pages/` — Streamlit pages
- `utils/` — helpers (`shared.py`, `safe.py`, etc.)
- `data/` — voorbeeld CSV's (kun je vervangen)
- `.streamlit/` — secrets.toml (optioneel)
- `.github/workflows/` — cleanup workflow (verwijdert rommel na upload)

## Gebruik
1. Upload deze bestanden/mappen naar je repo (root).
2. Ga naar **Actions → Clean Sweep** en run de workflow om oude rommel te verwijderen.
3. Start je app opnieuw.
